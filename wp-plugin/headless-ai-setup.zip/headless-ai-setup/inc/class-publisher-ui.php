<?php
/**
 * Publisher UI Module
 * Creates a simplified, white-labeled dashboard for non-admin authors.
 */

class HAIC_Publisher_UI {

    public function __construct() {
        add_action( 'admin_init', [ $this, 'intercept_non_admins' ] );
        add_action( 'admin_menu', [ $this, 'register_publisher_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_publisher_assets' ] );
        add_action( 'admin_post_haic_publish_post', [ $this, 'handle_form_submission' ] );
    }

    /**
     * Redirects non-admins away from standard WP dashboard to our custom UI.
     */
    public function intercept_non_admins() {
        if ( current_user_can( 'manage_options' ) ) {
            return;
        }

        // Only intercept if they can edit posts
        if ( current_user_can( 'edit_posts' ) ) {
            global $pagenow;
            
            // Allow ajax and post processing
            if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;
            if ( $pagenow === 'admin-post.php' ) return;

            // If they are trying to access standard pages, redirect them
            if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'haic-publisher' ) {
                wp_redirect( admin_url( 'admin.php?page=haic-publisher' ) );
                exit;
            }
        }
    }

    /**
     * Registers the custom menu page.
     */
    public function register_publisher_menu() {
        if ( current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( current_user_can( 'edit_posts' ) ) {
            // Remove all standard menus for this role
            global $menu;
            $menu = [];

            add_menu_page(
                'Publications',
                'Publications',
                'edit_posts',
                'haic-publisher',
                [ $this, 'render_publisher_dashboard' ],
                'dashicons-edit',
                1
            );
        }
    }

    /**
     * Enqueues CSS and JS for the custom UI.
     */
    public function enqueue_publisher_assets( $hook ) {
        if ( $hook !== 'toplevel_page_haic-publisher' ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style( 'haic-publisher-css', HAIC_PLUGIN_URL . 'assets/css/publisher.css', [], HAIC_VERSION );
        wp_enqueue_script( 'haic-publisher-js', HAIC_PLUGIN_URL . 'assets/js/publisher.js', [ 'jquery' ], HAIC_VERSION, true );
    }

    /**
     * Renders the custom Publisher UI.
     */
    public function render_publisher_dashboard() {
        $view = isset( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : 'dashboard';

        echo '<div class="haic-publisher-wrap">';
        
        if ( $view === 'dashboard' ) {
            $this->render_dashboard_view();
        } elseif ( $view === 'editor' ) {
            $this->render_editor_view();
        }

        echo '</div>';
    }

    private function render_dashboard_view() {
        $user_id = get_current_user_id();
        $recent_posts = get_posts([
            'author'      => $user_id,
            'post_status' => ['publish', 'draft'],
            'numberposts' => 10
        ]);

        ?>
        <div class="haic-header">
            <h1>My Publications</h1>
            <a href="?page=haic-publisher&view=editor" class="haic-btn haic-btn-primary">Write New Publication</a>
        </div>

        <?php if ( isset( $_GET['success'] ) ) : ?>
            <div class="haic-alert haic-alert-success">
                Publication saved successfully! It is now syncing to the live website.
            </div>
        <?php endif; ?>

        <div class="haic-card">
            <?php if ( empty( $recent_posts ) ) : ?>
                <p>You haven't written any publications yet.</p>
            <?php else : ?>
                <ul class="haic-post-list">
                    <?php foreach ( $recent_posts as $post ) : ?>
                        <li>
                            <div class="haic-post-info">
                                <strong><?php echo esc_html( $post->post_title ); ?></strong>
                                <span class="haic-status haic-status-<?php echo esc_attr( $post->post_status ); ?>"><?php echo esc_html( ucfirst( $post->post_status ) ); ?></span>
                            </div>
                            <div class="haic-post-date">
                                <?php echo esc_html( get_the_date( '', $post ) ); ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        <?php
    }

    private function render_editor_view() {
        $categories = get_categories( [ 'hide_empty' => false ] );
        ?>
        <div class="haic-header">
            <h1>New Publication</h1>
            <a href="?page=haic-publisher" class="haic-btn haic-btn-secondary">Cancel</a>
        </div>

        <div class="haic-editor-container">
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="haic_publish_post">
                <?php wp_nonce_field( 'haic_publish_nonce', 'haic_nonce' ); ?>

                <div class="haic-main-column">
                    <div class="haic-form-group">
                        <input type="text" name="post_title" class="haic-input-title" placeholder="Publication Title" required>
                    </div>

                    <div class="haic-form-group">
                        <?php 
                        wp_editor( '', 'post_content', [
                            'textarea_name' => 'post_content',
                            'textarea_rows' => 20,
                            'media_buttons' => true,
                            'teeny'         => false,
                            'quicktags'     => true
                        ] ); 
                        ?>
                    </div>
                </div>

                <div class="haic-sidebar-column">
                    <div class="haic-card">
                        <h3>Publish</h3>
                        <button type="submit" class="haic-btn haic-btn-primary haic-btn-block">Publish Now</button>
                    </div>

                    <div class="haic-card">
                        <h3>Category</h3>
                        <select name="post_category" class="haic-select">
                            <?php foreach ( $categories as $category ) : ?>
                                <option value="<?php echo esc_attr( $category->term_id ); ?>"><?php echo esc_html( $category->name ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="haic-card">
                        <h3>Featured Image</h3>
                        <div class="haic-image-preview" id="haic-image-preview">
                            <p>No image selected</p>
                        </div>
                        <input type="hidden" name="featured_image_id" id="haic-featured-image-id" value="">
                        <button type="button" class="haic-btn haic-btn-secondary haic-btn-block" id="haic-upload-image-btn">Select Image</button>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }

    /**
     * Handles the form POST request to create the post.
     */
    public function handle_form_submission() {
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_die( 'Unauthorized' );
        }

        if ( ! isset( $_POST['haic_nonce'] ) || ! wp_verify_nonce( $_POST['haic_nonce'], 'haic_publish_nonce' ) ) {
            wp_die( 'Security check failed' );
        }

        $title    = isset( $_POST['post_title'] ) ? sanitize_text_field( $_POST['post_title'] ) : '';
        $content  = isset( $_POST['post_content'] ) ? wp_kses_post( wp_unslash( $_POST['post_content'] ) ) : '';
        $category = isset( $_POST['post_category'] ) ? intval( $_POST['post_category'] ) : 0;
        $image_id = isset( $_POST['featured_image_id'] ) ? intval( $_POST['featured_image_id'] ) : 0;

        if ( empty( $title ) ) {
            wp_die( 'Title is required' );
        }

        $post_data = [
            'post_title'    => $title,
            'post_content'  => $content,
            'post_status'   => 'publish',
            'post_author'   => get_current_user_id(),
            'post_category' => [ $category ]
        ];

        // This natively fires 'save_post', triggering our AI Engine and Webhooks!
        $post_id = wp_insert_post( $post_data );

        if ( ! is_wp_error( $post_id ) && $image_id > 0 ) {
            set_post_thumbnail( $post_id, $image_id );
        }

        wp_redirect( admin_url( 'admin.php?page=haic-publisher&success=1' ) );
        exit;
    }
}
