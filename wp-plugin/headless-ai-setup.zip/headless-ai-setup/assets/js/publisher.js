jQuery(document).ready(function($) {
    var mediaUploader;

    $('#haic-upload-image-btn').on('click', function(e) {
        e.preventDefault();

        // If the uploader object has already been created, reopen the dialog
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }

        // Extend the wp.media object
        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Featured Image',
            button: {
                text: 'Choose Image'
            },
            multiple: false // Set to true to allow multiple files to be selected
        });

        // When a file is selected, grab the URL and set it as the text field's value
        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            
            // Set the hidden input value to the attachment ID
            $('#haic-featured-image-id').val(attachment.id);

            // Update the preview area
            $('#haic-image-preview').html('<img src="' + attachment.url + '" alt="Preview">');
            
            // Change button text
            $('#haic-upload-image-btn').text('Change Image');
        });

        // Open the uploader dialog
        mediaUploader.open();
    });
});
